// Vercel Serverless Function for Agora Token Generation
// This file will be deployed as: /api/agora/token

// Use agora-token (newer package) or agora-access-token (deprecated but still works)
let RtcTokenBuilder, RtcRole;
try {
    const agoraToken = require('agora-token');
    RtcTokenBuilder = agoraToken.RtcTokenBuilder;
    RtcRole = agoraToken.RtcRole;
} catch (e) {
    // Fallback to deprecated package if agora-token not available
    const agoraAccessToken = require('agora-access-token');
    RtcTokenBuilder = agoraAccessToken.RtcTokenBuilder;
    RtcRole = agoraAccessToken.RtcRole;
}

export default async function handler(req, res) {
    // Enable CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }
    
    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed. Use POST.' });
    }
    
    try {
        const { channelName, uid, role } = req.body;

        // Validate required fields
        if (!channelName) {
            return res.status(400).json({ 
                error: 'channelName is required' 
            });
        }

        // Get credentials from environment variables
        const APP_ID = process.env.AGORA_APP_ID || '89fdd88c9b594cf0947a48a8730e5f62';
        const APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE || 'd082915a4058446e8537acf5df266736';

        // Validate App Certificate
        if (!APP_CERTIFICATE || APP_CERTIFICATE === 'YOUR_APP_CERTIFICATE_HERE') {
            return res.status(500).json({ 
                error: 'Server configuration error: App Certificate not set',
                message: 'Please configure AGORA_APP_CERTIFICATE environment variable in Vercel'
            });
        }

        // Parse UID (default to 0 for auto-assigned)
        const userId = uid !== undefined ? parseInt(uid) : 0;

        // Determine role
        const roleStr = role || 'publisher';
        const rtcRole = roleStr === 'publisher' ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER;

        // Calculate expiration time (1 hour from now)
        const currentTime = Math.floor(Date.now() / 1000);
        const expirationTimeInSeconds = currentTime + 3600; // 1 hour

        // Generate token
        const token = RtcTokenBuilder.buildTokenWithUid(
            APP_ID,
            APP_CERTIFICATE,
            channelName,
            userId,
            rtcRole,
            expirationTimeInSeconds
        );

        console.log(`✅ Token generated for channel: ${channelName}, UID: ${userId}, Role: ${roleStr}`);

        // Return token
        return res.status(200).json({
            token: token,
            expiresIn: 3600,
            channelName: channelName,
            uid: userId,
            role: roleStr
        });

    } catch (error) {
        console.error('❌ Error generating token:', error);
        return res.status(500).json({ 
            error: 'Failed to generate token',
            message: error.message 
        });
    }
}
